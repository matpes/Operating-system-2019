/*
 * IVTEntry.cpp
 *
 *  Created on: May 20, 2019
 *      Author: OS1
 */
#include <dos.h>
#include "IVTEntry.h"
#include "Makroi.h"
#include "KernelE.h"
IVTEntry * IVTEntry::interruptVectorTable[256] = { 0 };

IVTEntry::IVTEntry(IVTNo ivtno, pointerToFunction pointer) {
	oldRoutine = 0;
#ifndef BCC_BLOCK_IGNORE
	lock;
	oldRoutine = getvect(ivtno);
	setvect(ivtno, pointer);
#endif

	this->myEvent = 0;
	this->myEntry = ivtno;
	interruptVectorTable[ivtno] = this;

#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void IVTEntry::signal() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (myEvent) {
		myEvent->signal();
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void IVTEntry::doOldRoutine() {

#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (oldRoutine) {
		oldRoutine();
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

IVTEntry* IVTEntry::getIVTEntry(IVTNo ivtno) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	IVTEntry* e = interruptVectorTable[ivtno];
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return e;
}

IVTEntry::~IVTEntry() {
#ifndef BCC_BLOCK_IGNORE
	lock;
	setvect(myEntry, oldRoutine); //Vratimo staru rutinu na pocetni ulaz IVTabele
#endif
	interruptVectorTable[myEntry] = 0;
	myEvent = 0;
	if (oldRoutine) {
		oldRoutine();//JK
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}
