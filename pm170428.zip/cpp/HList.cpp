/*
 * HList.cpp
 *
 *  Created on: May 21, 2019
 *      Author: OS1
 */

#include "HList.h"
#include "Makroi.h"
HandlerList::HandlerList() {
	first = last = iter = 0;
}


HandlerList* HandlerList::deepCopy(){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	HandlerList * copyFirst = new HandlerList();
	for(setIter(); isIterNotNull(); nextIter()){
		copyFirst->insert(getIterFunction());
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return copyFirst;
}

void HandlerList::insert(SignalHandler signalHanlder) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (signalHanlder) {
		Elem *neww = new Elem(signalHanlder);
		if (first) {
			last->next = neww;
			last = neww;
		} else {
			first = neww;
			last = neww;
		}
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


int HandlerList::isIterNotNull() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 1;
	} else {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 0;
	}
}

SignalHandler HandlerList::getIterFunction() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return iter->handlerFunction;
	} else {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 0;
	}
}

void HandlerList::nextIter() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
		iter = iter->next;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


void HandlerList::setIter() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	iter = first;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}







void HandlerList::swap(SignalHandler hand1, SignalHandler hand2) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem *prim, *sec;
	int haventFoundPrim = 1, haventFoundSecond = 1;
	prim = sec = first;
	while (prim && sec && (haventFoundPrim || haventFoundSecond)) {
		if (haventFoundPrim) {
			if (prim->handlerFunction == hand1) {
				haventFoundPrim = 0;
			} else {
				prim = prim->next;
			}
		}
		if (haventFoundSecond) {
			if (sec->handlerFunction == hand2) {
				haventFoundSecond = 0;
			} else {
				sec = sec->next;
			}
		}
	}
	if (haventFoundPrim || haventFoundSecond || (prim == sec)) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return;
	} else {
		SignalHandler temp = prim->handlerFunction;
		prim->handlerFunction = sec->handlerFunction;
		sec->handlerFunction = temp;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


HandlerList::~HandlerList() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem* old = first;
	while(first){
		first = first->next;
		delete old;
		old = first;
	}
	last = iter = first = 0;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}








