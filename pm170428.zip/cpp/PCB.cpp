/*
 * PCB.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */
#include <dos.h>
#include <iostream.h>
#include "PCB.h"
#include "DList.h"
#include "Thread.h"
#include "Makroi.h"
#include "Idle.h"
#include "SCHEDULE.H"
#include "KernelS.h"
#include "HQueue.h"
#include "HList.h"
#include "Timer.h"
void handler0();
int PCB::dispatchRequested = 0;
int PCB::dispatchPossible = 1;
DList * PCB::headOfALLPCB = new DList();
PCB * PCB::idle = 0;
Thread* PCB::mainThread = 0;
int PCB::globalyBlockedSignals[maxNumOfSignal] = { 0 };

PCB::PCB(StackSize stackSize_, Time time_, Thread * thread) {
	creator = running;
	for (int i = 0; i < maxNumOfSignal; i++) {
		if (creator) {
			blockedSignals[i] = creator->blockedSignals[i];
			if (creator->signalVector[i]) {
				signalVector[i] = creator->signalVector[i]->deepCopy();
			} else {
				signalVector[i] = 0;
			}
			//Kada se pravi dete, njegov ulaz treba da bude isti kao ocev, ali kada
		} else {
			blockedSignals[i] = 0;
			signalVector[i] = 0;
		}
	}
	registerHandler(0, handler0);
	//signalVector[0]->insert(&handler0);
	handlerQueue = new HandlerQueue();

	myThread = thread;
	if (stackSize_ > 65536) {
		stackSize_ = 65536;
	}
	Id = ++IDG;
	stackSize = stackSize_;
	timeSlice = time_;
	currentState = started;
	ss = sp = bp = 0;
	mySemaphore = 0;
	myReturn = 0;
	stack = 0;
	blockedThreads = new DList();
	headOfALLPCB->insert(this);
}

void PCB::blockSignal(SignalId signal) {
	blockedSignals[signal] = 1;
}

void PCB::blockSignalGlobally(SignalId signal) {
	globalyBlockedSignals[signal] = 1;
}

void interrupt PCB::dispatcher() {

	if (!dispatchPossible) {
		dispatchRequested = 1;
		return;
	}

	dispatchRequested = 0;

#ifndef BCC_BLOCK_IGNORE
	running -> ss = _SS;
	running -> sp = _SP;
	running -> bp = _BP;
#endif

	if (running != idle && running->currentState == ready) {

		Scheduler::put(running);
	}

	running = Scheduler::get();
	if (running) {

	} else {
		running = idle;
	}

#ifndef BCC_BLOCK_IGNORE
	_SS = running -> ss;
	_SP = running -> sp;
	_BP = running -> bp;
#endif

	if (running != PCB::idle) {
		dispatchPossible = 0;
#ifndef BCC_BLOCK_IGNORE
		asm {pushf; sti;}
#endif
		PCB::running->handleSignals();
#ifndef BCC_BLOCK_IGNORE
		asm {popf;}
#endif
		dispatchPossible = 1;
	}
	if (dispatchRequested) {
		dispatch();
	}

}

void PCB::finalizeThread() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	//cout << "Finalizing thread " << running->Id << endl;
	for (blockedThreads->setIter(); blockedThreads->isIterNotNull();
			blockedThreads->nextIter()) {
		PCB* blockedThread = blockedThreads->getItterPCB();

		blockedThread->currentState = ready;
		Scheduler::put(blockedThread);
	}

	delete blockedThreads;
	blockedThreads = 0;

	if (creator) {
		//cout << "Creator " << running->Id << endl;
		creator->signal(1);
	}
	currentState = finished;

	if (blockedSignals[2] == 0 && globalyBlockedSignals[2] == 0
			&& signalVector[2] != 0) {
		HandlerList *e = signalVector[2];
		for (e->setIter(); e->isIterNotNull(); e->nextIter()) {
			(*e->getIterFunction())();
		}
	}
	//cout << "Last goodbye before leaving dispatch!" << endl;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	dispatchPossible = 1;
	dispatch();
}

PCB* PCB::getPCBById(int ID) {
	return headOfALLPCB->getPCBByID(ID);
}

int PCB::getID() {
	return Id;
}

void PCB::handleSignals() {

	HandlerQueue blockedQ;
	while (running->handlerQueue->first) {
		//cout << endl << running->handlerQueue->first << "je vrednost pokazivaca na prvi" << endl;
		//cout << "Handling signals " << running->Id << endl;
		int i = running->handlerQueue->first->id;
		HandlerList *e = running->handlerQueue->get();
		if (i >= maxNumOfSignal) {
			continue;
		}
		if (PCB::globalyBlockedSignals[i] || running->blockedSignals[i]) {
			blockedQ.insert(e, i);
		} else {
			e->setIter();
			while (e->isIterNotNull()) {
				//cout << e << endl;
				(*e->getIterFunction())();
				e->nextIter();
			}
		}
	}
	//cout << "Zavrsio je handler za Handing signals " << running->Id << endl;
	while (blockedQ.first) {
		int i = blockedQ.first->id;
		running->handlerQueue->insert(blockedQ.get(), i);
	}

}

void PCB::registerHandler(SignalId signal, SignalHandler handler) {
	if (signalVector[signal] == 0) {
		signalVector[signal] = new HandlerList();
	}
	signalVector[signal]->insert(handler);
}

void PCB::signal(SignalId signal) {
	//cout << "Pozvan je signal " << signal << " za nit ciji je id " << this->Id
	//<< endl;
	if (signalVector[signal] != 0) {
		HandlerList* newList = signalVector[signal]->deepCopy();
		handlerQueue->insert(newList, signal);
	}
}

void PCB::stackInitialization() {
	stackSize = stackSize / sizeof(unsigned);
	stack = new unsigned[stackSize];
#ifndef BCC_BLOCK_IGNORE
	stack[stackSize - 1] = FP_SEG(myThread);
	stack[stackSize - 2] = FP_OFF(myThread);
#endif

	stack[stackSize - 3] = 16;
	stack[stackSize - 4] = 10;
	stack[stackSize - 5] = 0x200;

#ifndef BCC_BLOCK_IGNORE
	stack[stackSize - 6] = FP_SEG(&wrapper);
	stack[stackSize - 7] = FP_OFF(&wrapper);
	sp = FP_OFF(stack + stackSize - 16);
	ss = FP_SEG(stack + stackSize - 16);
#endif
	bp = sp;
}

int PCB::IDG = 0;

PCB* PCB::running = 0;

void PCB::start() {
	if (currentState == started) {
		stackInitialization();
		currentState = ready;
		if (this != PCB::idle) {
			Scheduler::put(this);
		}
	}
}

void PCB::swap(SignalId id, SignalHandler hand1, SignalHandler hand2) {
	if (signalVector[id] && hand1 != hand2) {
		signalVector[id]->swap(hand1, hand2);
	}
}

void PCB::unblockSingal(SignalId signal) {
	blockedSignals[signal] = 0;
}

void PCB::unblockSingalGlobally(SignalId signal) {
	globalyBlockedSignals[signal] = 0;
}

void PCB::unregisterAllHandlers(SignalId id) {
	delete signalVector[id];
	signalVector[id] = 0;
}

void PCB::waitToComplete() {
	if (currentState == started || currentState == finished) {
		return;
	}
	if (this == idle || this == running) {
		return;
	}
	running->currentState = blocked;
	blockedThreads->insert(running);
	dispatch();
}

void PCB::wrapper(Thread* myThread) {
	myThread->run();
	PCB::running->finalizeThread();
}

PCB::~PCB() {
	headOfALLPCB->deletePCB(this);
	delete[] stack;
	stack = 0;
	delete blockedThreads;
	blockedThreads = 0;
}

void handler0() {
	//cout << "called handler 0 for " << PCB::running->Id << endl;
	PCB::running->finalizeThread();
}
