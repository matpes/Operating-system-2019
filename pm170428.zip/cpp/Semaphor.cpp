/*
 * Semaphore.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#include "Makroi.h"
#include "Semaphor.h"
#include "KernelS.h"
Semaphore::Semaphore(int init) {
	myImpl = new KernelSemaphore(init);
}

int Semaphore::signal(int n) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif

	int x = myImpl->signal(n);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return x;
}

int Semaphore::val() const {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	int x = myImpl->value;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return x;
}

int Semaphore::wait(Time maxTimeToWait) {

#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	int x = myImpl->wait(maxTimeToWait);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return x;
}

Semaphore::~Semaphore() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	delete myImpl;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}



