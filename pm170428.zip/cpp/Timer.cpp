/*
 * Timer.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */
#include <dos.h>
#include <iostream.h>
#include "Timer.h"
#include "KernelS.h"
#include "Semaphor.h"
#include "Makroi.h"
#include "PCB.h"
#include "SCHEDULE.H"
void tick();

TimerList::Elem* TimerList::head = 0;

void TimerList::add(Elem *e) {
	e->pcb->currentState = PCB::blocked;
	Elem * curr = head;
	Elem * prev = 0;
	while (curr && (curr->time < e->time)) {
		e->time -= curr->time;
		prev = curr;
		curr = curr->next;
	}

	if (!prev) {
		head = e;
	} else {
		prev->next = e;
	}
	e->next = curr;

	if (curr) {
		curr->time -= e->time;
	}

}

void TimerList::refresh() {

	if (TimerList::head) {

		TimerList::head->time = TimerList::head->time - 1;
		while (TimerList::head && (TimerList::head->time <= 0)) {
			Elem * old = TimerList::head;
			PCB* pecebe = TimerList::head->pcb;
			pecebe->currentState=PCB::ready;
			if (pecebe->mySemaphore) {
				++(pecebe->mySemaphore->value);
				pecebe->mySemaphore->blockedPCBs->deletePCB(pecebe);
				pecebe->mySemaphore = 0;
				pecebe->myReturn = 0;
			}
			Scheduler::put(pecebe);
			TimerList::head = TimerList::head->next;

			delete old;
		}
	}

}

void TimerList::remove(PCB * p) {

	TimerList::Elem* curr = TimerList::head;
	TimerList::Elem* prev = 0;
	//cout << "Usao u remove\n";
	while (curr && curr->pcb != p) {
		prev = curr;
		curr = curr->next;
	}
	if (!curr) {
		//cout << "WHAT THE FUCK?\n";
		return;
	}
	if (!prev) {
		//cout << "Nasao da izbaci prvi "<<endl;
		head = head->next;
		head->time += curr->time;
		delete curr;
		return;
	}
	//cout << "Nasao da izbaci iz sredine \n";
	if (curr->next) {
		curr->next->time += curr->time;
	}
	prev->next = curr->next;
	delete curr;

}

void TimerList::pisi() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	TimerList::Elem* curr = TimerList::head;
	while (curr) {
		cout << "ID: " << curr->pcb->Id << " timer: " << curr->time << endl;
		curr = curr->next;
	}

#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Timer::activate() {
#ifndef BCC_BLOCK_IGNORE
	Timer::oldTimer=getvect(8);
	setvect(8, &Timer::timer);
#endif
	currentTime = 0;
}

int Timer::currentTime = 0;
void Timer::deactivate() {
#ifndef BCC_BLOCK_IGNORE
	setvect(8, oldTimer);
#endif
}
pointerToFunction Timer::oldTimer = 0;
void Timer::resetCounter() {
	Timer::currentTime = 0;
}

void interrupt Timer::timer(...) {

	(*Timer::oldTimer)();
	//cout << "\nOkinuo tajmer\n";
	tick();
	TimerList::refresh();
	if (PCB::running && PCB::running->timeSlice) {
		++currentTime;
		if (currentTime >= PCB::running->timeSlice) {
			Timer::currentTime = 0;
			dispatch();
		}
	}
}
