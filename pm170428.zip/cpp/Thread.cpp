/*
 * Thread.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#include <dos.h>
#include <iostream.h>
#include "Thread.h"
#include "Makroi.h"
#include "PCB.h"


Thread::Thread(StackSize stackSize, Time timeSlice) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB = new PCB(stackSize, timeSlice, this);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::blockSignal(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->blockSignal(signal);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


void Thread::blockSignalGlobally(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	PCB::blockSignalGlobally(signal);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


ID Thread::getId() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	ID i = myPCB->getID();
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return i;
}

ID Thread::getRunningId() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	ID i = PCB::running->Id;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return i;
}

Thread * Thread::getThreadById(ID id) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Thread* i = (PCB::getPCBById(id))->myThread;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return i;
}

void Thread::registerHandler(SignalId signal, SignalHandler handler){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->registerHandler(signal, handler);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::signal(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->signal(signal);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


void Thread::start() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->start();
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::swap(SignalId id, SignalHandler hand1, SignalHandler hand2){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->swap(id, hand1, hand2);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::unblockSignal(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->unblockSingal(signal);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


void Thread::unblockSignalGlobally(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	PCB::unblockSingalGlobally(signal);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::unregisterAllHandlers(SignalId id){
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->unregisterAllHandlers(id);
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void Thread::waitToComplete() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	myPCB->waitToComplete();
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

Thread::~Thread() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	//cout<< "Poziva se destruktor za nit " << getId() << endl;
	waitToComplete();
	delete myPCB;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


void dispatch() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	PCB::dispatcher();
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}
