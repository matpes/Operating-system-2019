/*
 * DList.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */
#include "DList.h"
#include "Makroi.h"
#include "PCB.h"
#include <iostream.h>

DList::DList() {
	first = iter = last = 0;
}

void DList::setIter() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	iter = first;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void DList::setIterToLast() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	iter = last;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}
int DList::isIterNotNull() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 1;
	} else {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 0;
	}

}

void DList::prevIter() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
		iter = iter->prev;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void DList::nextIter() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
		iter = iter->next;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void DList::insert(PCB * pcb) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem * neww = new Elem(pcb, first);
	if (first) {
		first->prev = neww;
	} else {
		last = neww;
	}
	first = neww;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void DList::insertAtEnd(PCB * pcb) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem *neww = new Elem(pcb, 0, last);
	if (first) {
		 last->next = neww;
		 last = neww;
	} else {
		first = last = neww;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

void DList::deleteItterPCB() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter == 0) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return;
	}
	if (iter->next) {
		iter->next->prev = iter->prev;
	}
	if (iter->prev) {
		iter->prev->next = iter->next;
	}
	Elem *Liter = iter;
	if (iter == first) {
		first = first->next;
	}
	if (iter == last) {
		last = last->prev;
	}
	if (!first) {
		first = last = 0;
	}
	iter = iter->next;
	delete Liter;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return;
}

PCB* DList::getFirstPCB() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (!first) {
#ifndef BCC_BLOCK_IGNORE
		unlock;
#endif
		return 0;
	}
	Elem *d = first;
	PCB * p = first->pcb;
	first = first->next;
	if (d == iter) {
		iter = iter->next;
	}
	if (!first) {
		last = iter = 0;
	} else {
		first->prev = 0;
	}
	delete d;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return p;
}

PCB* DList::getLastPCB() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (!last){
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return 0;
	}
	Elem *d = last;
	PCB * p = last->pcb;
	last = last->prev;
	if (d == iter) {
		iter = iter->prev;
	}
	if (!last) {
		first = iter = 0;
	} else {
		last->next = 0;
	}
	delete d;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return p;
}

PCB* DList::getItterPCB() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (iter) {
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return iter->pcb;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return 0;
}

void DList::deletePCB(PCB *pcb) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	if (pcb == 0){
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return;
	}
	Elem * curr = first;
	while (curr && curr->pcb != pcb) {
		curr = curr->next;
	}
	if (curr == 0) {
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return;
	}
	if (curr->next) {
		curr->next->prev = curr->prev;
	}
	if (curr->prev) {
		curr->prev->next = curr->next;
	}
	if (iter == curr) {
		iter = iter->next;
	}
	if (curr == first) {
		first = first->next;
	}
	if (curr == last) {
		last = last->prev;
	}
	if (first == 0) {
		last = iter = 0;
	}

	delete curr;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return;
}

PCB* DList::getPCBByID(ID id) {
	if (!first) {
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return 0;
	}
	Elem* curr = first;
	while (curr && curr->pcb->Id != id) {
		curr = curr->next;
	}
	if (!curr){
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
		return 0;}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
	return curr->pcb;

}

DList::~DList() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem * old = first;
	while (first) {
		first = first->next;
		delete old;
		old = first;
	}
	first = last = iter = 0;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


