/*
 * HQueue.cpp
 *
 *  Created on: May 21, 2019
 *      Author: OS1
 */

#include "HQueue.h"
#include "HList.h"
#include "Makroi.h"
HandlerQueue::HandlerQueue() {
	first = last = 0;
}

void HandlerQueue::insert(HandlerList* hl, SignalId id) {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif

	Elem * neww = new Elem(hl, id);
	if (first) {
		last->next = neww;
	} else {
		first = neww;
	}
	last = neww;

#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}


HandlerList* HandlerQueue::get() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif

	HandlerQueue::Elem * toBeDeleted = first;
	first = first->next;
	HandlerList* toBeReturned = toBeDeleted->handlerList;
	toBeDeleted->next = 0;
	delete toBeDeleted;
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif

	return toBeReturned;
}


HandlerQueue::~HandlerQueue() {
#ifndef BCC_BLOCK_IGNORE
	lock;
#endif
	Elem *old = first;
	while (first) {
		first = first->next;
		delete old->handlerList;
		delete old;
		old = first;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock;
#endif
}

