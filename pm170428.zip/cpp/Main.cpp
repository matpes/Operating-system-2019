/*
 * Main.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */


#include "Thread.h"
#include "PCB.h"
#include "Idle.h"
#include "DList.h"
#include "Timer.h"
int userMain(int argc, char * argv[]);

int main(int argc, char * argv[]){

	PCB::mainThread = new Thread();

	PCB::running = PCB::mainThread->myPCB;
	PCB::running->creator = 0;
	PCB::running->currentState = PCB::ready;
	Idle * mainIdle = new Idle();
	PCB::idle = mainIdle->getPCB();
	PCB::idle->creator = 0;
	mainIdle->start();
	cout << PCB::idle->Id << " Je id Idle-a"<<endl;
	cout << PCB::mainThread->getId() << " Je id main-a"<<endl;

	cout << "Entering from UserMain\n";
	Timer::activate();
	int ret = userMain(argc, argv);
	Timer::deactivate();
	cout << "Returned from UserMain\n";
	delete mainIdle;
	delete PCB::running->myThread;

	return ret;

}
