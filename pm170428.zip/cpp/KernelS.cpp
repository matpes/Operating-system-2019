/*
 * KernelS.cpp
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#include <IOSTREAM.H>
#include "PCB.h"
#include "SCHEDULE.H"
#include "KernelS.h"
#include "DList.h"
#include "Timer.h"
KernelSemaphore::KernelSemaphore(int init) {
	blockedPCBs = new DList();
	value = init;
}

int KernelSemaphore::signal(int n) {
	//cout << "Neko je pozvao signal, a taj neko je: " << PCB::running->id
	//	<< endl;
	if (n < 0)
		return n;
	int counter = n;
	int numberOfUnblocked = 0;
	do {
		PCB* pcbg = blockedPCBs->getLastPCB();
		if (!pcbg) {
			++value;
			counter = -2;
		} else {
			TimerList::remove(pcbg);
			pcbg->currentState = PCB::ready;
			pcbg->myReturn = 1;
			Scheduler::put(pcbg);
			++numberOfUnblocked;
			--counter;
			++value;
		}
	} while (counter > 0);

	if (n == 0)
		return 0;
	if (n - numberOfUnblocked > 0) {
		value += n - numberOfUnblocked - 1;
	}
	return numberOfUnblocked;
}

int KernelSemaphore::wait(Time maxTimeToWait) {
	if (--value < 0) {
		PCB::running->currentState = PCB::blocked;
		PCB::running->mySemaphore = this;
		blockedPCBs->insertAtEnd(PCB::running);
		if (maxTimeToWait > 0) {
			TimerList::Elem *e = new TimerList::Elem(maxTimeToWait,
					PCB::running);
			TimerList::add(e);
		}
		dispatch();
		//cout << "Vrednost semafora je " << value << endl;
		return PCB::running->myReturn;
	}
	return 1;
}

KernelSemaphore::~KernelSemaphore() {

	delete blockedPCBs;
}

