/*
 * KernelE.cpp
 *
 *  Created on: May 20, 2019
 *      Author: OS1
 */

#include "KernelE.h"
#include "PCB.h"
#include "IVTEntry.h"
#include "SCHEDULE.H"

KernelEvent::KernelEvent(IVTNo number) {
	this->value = 0;
	this->eventPCB = PCB::running; //running PCB, a ne rady stanje
	this->number = number;
	if(IVTEntry::interruptVectorTable[number]){
		IVTEntry::interruptVectorTable[number]->myEvent = this;
	}
}


void KernelEvent::signal() {

	if(value > -1){
		value = 1;
	}else{
		value = 0;
		eventPCB->currentState = PCB::ready;
		Scheduler::put(eventPCB);
	}
}

void KernelEvent::wait() {
	if(PCB::running==eventPCB){
		if(value < 1){ //Ako je value 0 ili -1
			value = -1;
			eventPCB->currentState = PCB::blocked;
			dispatch();
		}else{
			value = 0; //Signal za prekid je stigao pre waita i samo prodejmo
		}
	}

}


KernelEvent::~KernelEvent(){
	if(value == -1){	//Ako je nit blokirana, odblokiramo je
		this->signal();
	}
	if(IVTEntry::interruptVectorTable[number]){ //obrisemo event IVTabele
		IVTEntry::interruptVectorTable[number] -> myEvent = 0;
	}
}
