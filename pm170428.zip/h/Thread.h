/*
 * Thread.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef THREAD_H_
#define THREAD_H_

typedef unsigned long StackSize;
const StackSize defaultStackSize = 4096;
typedef unsigned int Time; // time, x 55ms
const Time defaultTimeSlice = 2; // default = 2*55ms
typedef int ID;

typedef unsigned SignalId;
typedef void (*SignalHandler)();

class PCB;
// Kernel's implementation of a user's thread
class Idle;

class Thread {
public:

	void blockSignal(SignalId signal);
	static void blockSignalGlobally(SignalId signal);

	void registerHandler(SignalId singal, SignalHandler handler);
	void signal(SignalId signal);
	void swap(SignalId id, SignalHandler hand1, SignalHandler hand2);
	void unblockSignal(SignalId signal);
	static void unblockSignalGlobally(SignalId signal);
	void unregisterAllHandlers(SignalId id);

	void start();
	void waitToComplete();
	virtual ~Thread();
	ID getId();
	static ID getRunningId();
	static Thread * getThreadById(ID id);
protected:
	friend class PCB;
	friend class Idle;
	friend main(int argc, char *argv[]);
	Thread(StackSize stackSize = defaultStackSize, Time timeSlice =
			defaultTimeSlice);
	virtual void run() {
	}
//private:
public:
	PCB* myPCB;
};
void dispatch();

#endif /* THREAD_H_ */
