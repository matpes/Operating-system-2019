/*
 * PCB.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef PCB_H_
#define PCB_H_
#include "Thread.h"
const int maxNumOfSignal = 16;
class DList;
class KernelSemaphore;
class Idle;
class HandlerQueue;
class HandlerList;
// handleSignals
class PCB {
public:

	static int globalyBlockedSignals[maxNumOfSignal];
	int blockedSignals[maxNumOfSignal];
	HandlerList* signalVector[maxNumOfSignal];

	PCB* creator;
	HandlerQueue *handlerQueue;
	void signal(SignalId signal);
	void registerHandler(SignalId singal, SignalHandler handler);
	void unregisterAllHandlers(SignalId id);
	void swap(SignalId id, SignalHandler hand1, SignalHandler hand2);
	static void handleSignals();
	void blockSignal(SignalId signal);
	static void blockSignalGlobally(SignalId signal);
	void unblockSingal(SignalId signal);
	static void unblockSingalGlobally(SignalId signal);

	PCB(StackSize stackSize_, Time time_, Thread * thread);
	static enum PCBState {
		started, ready, blocked, finished
	};
	DList* blockedThreads;
	PCBState currentState;

	static int dispatchRequested;
	static int dispatchPossible;

	void finalizeThread();
	static void interrupt dispatcher();
	static PCB* getPCBById(int ID);
	int getID();
	static DList* headOfALLPCB;
	static int IDG;
	int Id;
	static PCB* idle;
	static Thread* mainThread;
	Thread * myThread;
	KernelSemaphore * mySemaphore;
	int myReturn;
	static PCB* running;

	void start();
	unsigned * stack;
	unsigned ss, sp, bp;
	StackSize stackSize;
	void stackInitialization();
	Time timeSlice;
	static void wrapper(Thread* myThread);
	void waitToComplete();
	~PCB();

};

#endif /* PCB_H_ */
