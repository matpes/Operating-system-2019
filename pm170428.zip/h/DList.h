/*
 * DList.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef DLIST_H_
#define DLIST_H_

#include "PCB.h"
#include "Makroi.h"
class DList{
public:

	struct Elem
	{
		PCB * pcb;
		Elem * next;
		Elem * prev;
		Elem(PCB *p = 0, Elem* ne = 0, Elem *pr = 0)
		{
			pcb = p;
			next = ne;
			prev = pr;
		}
	};
	DList();
	void setIter();
	void setIterToLast();
	int isIterNotNull();
	void nextIter();
	void prevIter();
	void insert(PCB * pcb);
	void insertAtEnd(PCB * pcb);
	void deleteItterPCB();
	PCB* getFirstPCB();
	PCB* getLastPCB();
	PCB* getItterPCB();
	void deletePCB(PCB *pcb);
	PCB* getPCBByID(ID id);
	Elem *first, *last, *iter;
	~DList();

};



#endif /* DLIST_H_ */
