/*
 * HList.h
 *
 *  Created on: May 21, 2019
 *      Author: OS1
 */

#ifndef HLIST_H_
#define HLIST_H_

#include "PCB.h"
typedef unsigned SignalId;
typedef void (*SignalHandler)();

class HandlerList {
public:
	HandlerList();
	struct Elem{
		SignalHandler handlerFunction;
		Elem* next;
		Elem(SignalHandler sh, Elem * n = 0){
			handlerFunction = sh;
			next = n;
		}
	};
	Elem *first, *iter, *last;
	void setIter();
	void nextIter();
	int isIterNotNull();
	SignalHandler getIterFunction();
	void insert(SignalHandler);
	void swap(SignalHandler hand1, SignalHandler hand2);
	HandlerList *deepCopy();
	~HandlerList();
};

#endif /* HLIST_H_ */
