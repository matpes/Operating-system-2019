/*
 * Idle.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef IDLE_H_
#define IDLE_H_
#include "Thread.h"
#include <iostream.h>

class Idle: public Thread {
public:
	Idle() :
			Thread(4096, 1) {
	}
	void run() {
		while (1) {
			dispatch();
		}
	}
	PCB* getPCB(){
		return myPCB;
	}
/*	virtual ~Idle() {
		waitToComplete();
	}*/
};

#endif /* IDLE_H_ */
