/*
 * event.h
 *
 *  Created on: May 20, 2019
 *      Author: OS1
 */

#ifndef EVENT_H_
#define EVENT_H_
#include "IVTEntry.h"
typedef unsigned char IVTNo;

#define PREPAREENTRY(numEntry, callOld) \
void interrupt inter##numEntry(...); \
IVTEntry newEntry##numEntry(numEntry, inter##numEntry); \
void interrupt inter##numEntry(...) { \
	if (callOld == 1) \
		newEntry##numEntry.oldRoutine(); \
	newEntry##numEntry.signal(); \
	dispatch(); \
}



class Event{
public:
	Event(IVTNo ivtNo);
	~Event();

	void wait();
protected:
	void signal(); //can call KernelEvent
	friend class KernelEvent;
private:
	KernelEvent* myImpl;
};

#endif /* EVENT_H_ */
