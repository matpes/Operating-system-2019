/*
 * IVTEntry.h
 *
 *  Created on: May 20, 2019
 *      Author: OS1
 */

#ifndef IVTENTRY_H_
#define IVTENTRY_H_


typedef unsigned char IVTNo;
typedef void interrupt (*pointerToFunction)(...);
class KernelEvent;

class IVTEntry{
public:
	IVTEntry(IVTNo, pointerToFunction);
	~IVTEntry();
	void doOldRoutine();
	void signal();
	static IVTEntry * getIVTEntry(IVTNo);
	static IVTEntry *interruptVectorTable[];
	IVTNo myEntry;
	KernelEvent *myEvent;
	pointerToFunction oldRoutine;

};



#endif /* IVTENTRY_H_ */
