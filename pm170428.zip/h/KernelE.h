/*
 * KernelE.h
 *
 *  Created on: May 20, 2019
 *      Author: OS1
 */

#ifndef KERNELE_H_
#define KERNELE_H_
typedef unsigned char IVTNo;
class PCB;
class KernelEvent{
public:

	friend class Event;
	KernelEvent(IVTNo number);
	PCB* eventPCB;
	IVTNo number;
	void signal();
	int value;
	void wait();
	~KernelEvent();
};



#endif /* KERNELE_H_ */
