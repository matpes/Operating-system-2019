/*
 * HQueue.h
 *
 *  Created on: May 21, 2019
 *      Author: OS1
 */

#ifndef HQUEUE_H_
#define HQUEUE_H_

class HandlerList;
typedef unsigned SignalId;
class HandlerQueue{
public:
	HandlerQueue();
	struct Elem{
		Elem* next;
		HandlerList* handlerList;
		SignalId id;
		Elem(HandlerList* handlerList_, SignalId id_, Elem* next_ = 0){
			handlerList = handlerList_;
			id = id_;
			next = next_;
		}
	};
	Elem *first, *last;
	void insert(HandlerList* hl, SignalId id);
	HandlerList* get();
	~HandlerQueue();
};



#endif /* HQUEUE_H_ */
