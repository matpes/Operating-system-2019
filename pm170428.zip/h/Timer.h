/*
 * Timer.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef TIMER_H_
#define TIMER_H_
class PCB;
typedef void interrupt (*pointerToFunction)(...);
typedef unsigned int Time;

class TimerList{
public:

	struct Elem{
		volatile Time time;
		PCB * pcb;
		 Elem* next;
		Elem(Time timee, PCB* pcbb, Elem *nextt=0){
			time=timee;
			pcb=pcbb;
			next=nextt;
		}
	};
	static  Elem * head;
	static void add(Elem *e);
	static void refresh();
	static void remove(PCB *);
	static void pisi();
};

class Timer{
public:
	static void activate();
	static int currentTime;
	static void deactivate();
	static pointerToFunction oldTimer;
	static void resetCounter();

	static void interrupt timer(...);



};



#endif /* TIMER_H_ */
