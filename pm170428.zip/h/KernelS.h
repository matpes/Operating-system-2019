/*
 * KernelS.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef KERNELS_H_
#define KERNELS_H_

#include "DList.h"

class KernelSemaphore{
public:
	KernelSemaphore(int init=1);
	int value;
	int wait(Time maxTimeToWait);
	int signal(int n = 0);
	DList * blockedPCBs;

	virtual ~KernelSemaphore();
};




#endif /* KERNELS_H_ */
