/*
 * Makroi.h
 *
 *  Created on: May 18, 2019
 *      Author: OS1
 */

#ifndef MAKROI_H_
#define MAKROI_H_

#define lock asm{ pushf; cli; }
#define unlock asm{ popf; }

void tick();

#endif /* MAKROI_H_ */
